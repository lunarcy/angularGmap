/**
* Javascript Exercise 2 - AngularJS - Directives.
* @ Bin Jiang, 10 June, 2015
* 
**/

// app module. 
var app = angular.module('myApp', []);
